package com.example.projecttwo;

public class Login {
    private String username;
    private String password;

    public Login() {}

    public Login(String id, String pw) {
        this.username = id;
        this.password = pw;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String id) {
        this.username = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String pw) {
        this.password = pw;
    }
}
