package com.example.projecttwo;

public class GoalWeight {
    private String goalWeight;
    private String username;

    public GoalWeight(){}
//    public GoalWeight(String goalWeight) {
//        this.goalWeight = goalWeight;
//    }
    public GoalWeight(String goalWeight, String username) {
        this.goalWeight = goalWeight;
        this.username = username;
    }

    public String getGoalWeight() {
        return goalWeight;
    }

    public void setGoalWeight(String goalWeight) {
        this.goalWeight = goalWeight;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
