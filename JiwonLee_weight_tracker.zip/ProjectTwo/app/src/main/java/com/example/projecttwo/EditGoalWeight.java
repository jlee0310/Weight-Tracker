package com.example.projecttwo;

import static android.Manifest.permission.SEND_SMS;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class EditGoalWeight extends AppCompatActivity {
    private EditText editedGoalWeight;
    private Button enterGoalWeight;
    private RadioGroup yesOrNo;
    private RadioButton radioYes;
    private RadioButton radioNo;
    private EditText phoneNumber;
    private UserData mUserdata;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_goal_weight);

        editedGoalWeight = findViewById(R.id.your_goal_weight);
        enterGoalWeight = findViewById(R.id.button_goal_weight);
        phoneNumber = findViewById(R.id.editTextPhone);
        yesOrNo = findViewById(R.id.yesOrNo);
        yesOrNo.clearCheck();
        radioYes = findViewById(R.id.radioButtonYes);
        radioNo = findViewById(R.id.radioButtonNo);
        mUserdata = UserData.getInstance(getApplicationContext());

        enterGoalWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sPhone = phoneNumber.getText().toString().trim();
                String goalWeight = editedGoalWeight.getText().toString().trim();

                if(!sPhone.isEmpty() && !goalWeight.isEmpty()) {

                    GoalWeight goal = new GoalWeight(goalWeight, getIntent().getStringExtra("receivedUsername"));
                    mUserdata.addGoalWeight(goal);

                    //Log.d("GoalWeight", "addGoalWeight from : " + getIntent().getStringExtra("receivedUsername")+ " goal weight added");
                    Log.d("GoalWeight", "addGoalWeight from : " + goal.getUsername() + " goal weight added");
                    Intent intent = new Intent(EditGoalWeight.this, HelloUserActivity.class);

                    //intent.putExtra("goalWeight", goalWeight);
                    intent.putExtra("username", goal.getUsername());
                    intent.putExtra("goalWeight", goalWeight);
                    startActivity(intent);
                    // Getting yes to display on main screen
//                    if(radioYes.isChecked()) {
////                        Intent intent1 = new Intent(EditGoalWeight.this, HelloUserActivity.class);
//                        //String smsStatus = "You are getting SMS notification.";
////                        intent.putExtra("smsNotification", true);
////                        startActivity(intent);
//                    }
                }else {
                    Toast.makeText(getApplicationContext(), "Enter valid inputs.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    } //end onCreate

    public void setOnRadioClicked(View view) {
        if (ContextCompat.checkSelfPermission(EditGoalWeight.this, Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(), "You already set SMS notification", Toast.LENGTH_SHORT).show();
        } else {
            ActivityCompat.requestPermissions(EditGoalWeight.this
                    , new String[]{Manifest.permission.SEND_SMS}
                    ,100);
            if (radioYes.isChecked()) {


                Toast.makeText(getApplicationContext(), "SMS notification is set successfully!", Toast.LENGTH_SHORT).show();
            } else if (radioNo.isChecked()) {
                Toast.makeText(getApplicationContext(), "You are not receiving SMS notification.", Toast.LENGTH_SHORT).show();
            }
        }



    } //end of setOnRadioClicked()

    private void sendMessage() {
        String sPhone = phoneNumber.getText().toString().trim();
        String sMessage = "You reached your goal weight. congratulation!";
        // add if statements with goalWeight == DailyWeight

        if (sPhone.length() >0) {
            SmsManager smsManager = SmsManager.getDefault();
            //Send text message
            smsManager.sendTextMessage(sPhone, null, sMessage, null, null);
            //Display toast
            Toast.makeText(getApplicationContext(), "SMS notification is set successfully!", Toast.LENGTH_LONG).show();
        } else {
            //When edit text value is blank
            //Display toast
            Toast.makeText(getApplicationContext(), "Enter you phone number", Toast.LENGTH_SHORT).show();
        }
    }

    public Boolean gettingSMS() {
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //Check condition
        if (requestCode == 100 && grantResults.length > 0 && grantResults[0]
        == PackageManager.PERMISSION_GRANTED){
            //When permission is granted
            //Call method
            sendMessage();
        }else {
            //When permission is denied
            //Display toast
            Toast.makeText(getApplicationContext()
            ,"Permission denied!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

} //End
