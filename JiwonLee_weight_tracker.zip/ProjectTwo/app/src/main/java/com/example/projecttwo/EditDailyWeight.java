package com.example.projecttwo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class EditDailyWeight extends AppCompatActivity {

    private TextView showDateWeight;
    private EditText enterDailyWeight;
    private String selectedDate;
    private String selectedYear;
    private String selectedMonth;
    private Button enter;
    private UserData mUserdata;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.daily_weight);
        showDateWeight = findViewById(R.id.show_date);
        enterDailyWeight = findViewById(R.id.enterDailyWeight);
        enter = findViewById(R.id.button_daily_weight);

        // Singleton
        mUserdata = UserData.getInstance(getApplicationContext());

        // Getting date from user
        CalendarView calendar = (CalendarView) findViewById(R.id.calendarView);
        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int day) {

                selectedDate = String.valueOf(day);
                selectedYear = String.valueOf(year);
                selectedMonth = String.valueOf(month + 1);
                showDateWeight.setText(selectedYear + "." + selectedMonth + "." + selectedDate);


            }
        });

        // Getting daily weight from user
        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String dailyWeight = enterDailyWeight.getText().toString().trim();
                String weightedDate = selectedYear + "." + selectedMonth + "." + selectedDate;
                String receivedUsername = getIntent().getStringExtra("loggedIn");

                if(!dailyWeight.isEmpty() && !weightedDate.isEmpty()) {
                    DailyWeight newDaily = new DailyWeight(dailyWeight, weightedDate, receivedUsername);
//                    mUserdata.addDailyWeight(newDaily);
                    Log.d("Edit Daily Weight", "receivedUsername: " + receivedUsername);
                    newDaily.setDailyWeight(dailyWeight);
                    newDaily.setDates(weightedDate);
                    newDaily.setUsername(receivedUsername);

//                    Intent intent = new Intent(EditDailyWeight.this, HelloUserActivity.class);
//                    intent.putExtra("newDailyWeight", newDaily);
                    Log.d("from EditDailyWeight",
                          "Daily Weight: " + newDaily.getDailyWeight() +
                            " Dates: " + newDaily.getDates() +
                            " Username: " + newDaily.getUsername());
//                    setResult(Activity.RESULT_OK, intent);
//                    finish();

                    Intent intent = new Intent(EditDailyWeight.this, HelloUserActivity.class);
                    intent.putExtra("dailyWeight", dailyWeight);
                    intent.putExtra("dates", weightedDate);
                    intent.putExtra("username", receivedUsername);
                    startActivity(intent);
                      finish();
                }else {
                    Toast.makeText(getApplicationContext(), "Enter a valid daily weight.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    } //End onCreate
}
