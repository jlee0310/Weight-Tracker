package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class SignUpActivity extends AppCompatActivity {

    EditText userNameNew, passwordNew;
    TextView usernameStatus;
    Button getStarted;
    ListView listView;
    private UserData mUserdata;
    Login login;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);

        // Singleton
        mUserdata = UserData.getInstance(getApplicationContext());

        userNameNew = findViewById(R.id.input_username_new);
        passwordNew = findViewById(R.id.input_pw_new);
        usernameStatus = findViewById(R.id.username_status);
        getStarted = findViewById(R.id.button_getStarted);

        getStarted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = userNameNew.getText().toString().trim();
                String pw = passwordNew.getText().toString().trim();

                if (!username.isEmpty() && !pw.isEmpty()) {
                    Login login = new Login(username, pw);
                    if (mUserdata.addUser(login)) {
                        Toast.makeText(SignUpActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(SignUpActivity.this, HelloUserActivity.class);
                    intent.putExtra("username", username);
                    startActivity(intent);
                    } else {
                        String msg = "The username " + username + " already exists.";
                        Toast.makeText(SignUpActivity.this, msg, Toast.LENGTH_SHORT).show();
                    }
                } else if (username.isEmpty() && pw.isEmpty()) {
                    String msg = "Please enter valid information.";
                    Toast.makeText(SignUpActivity.this, msg, Toast.LENGTH_SHORT).show();
                }

            } // End of onClick
        });

    } // End of onCreate


} // End