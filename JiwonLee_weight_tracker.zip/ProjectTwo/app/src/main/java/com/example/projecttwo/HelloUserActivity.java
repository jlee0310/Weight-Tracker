package com.example.projecttwo;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class HelloUserActivity extends AppCompatActivity {

    private TextView showGoalWeight;
    private TextView showDailyWeight;
    private TextView showDates;
    private TextView helloUser;
    private TextView showWeightTrends;
    private UserData mUserdata;
    private Login login;
    private GoalWeight goal;
    private DailyWeight daily;
    private String loggedIn;
    private String dailyWeight;
    private String goalWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hello_user);
        mUserdata = UserData.getInstance(getApplicationContext());

        showGoalWeight = findViewById(R.id.gWeight);
        showDailyWeight = findViewById(R.id.dWeight);
        showDates = findViewById(R.id.date);
        helloUser = findViewById(R.id.helloUser);
        mUserdata = UserData.getInstance(getApplicationContext());
        showWeightTrends = findViewById(R.id.dailyWeightList);



        String receivedUsername = getIntent().getStringExtra("username");
        String receivedDailyWeight = getIntent().getStringExtra("dailyWeight");
        String receivedDate = getIntent().getStringExtra("dates");
        String receivedGoalWeight = getIntent().getStringExtra("goalWeight");

        goal = new GoalWeight(receivedGoalWeight, receivedUsername);
        daily = new DailyWeight(receivedDailyWeight, receivedDate, receivedUsername);



        helloUser.setText("Hello, " + receivedUsername + "!");
        loggedIn = receivedUsername;
        goalWeight = goal.getGoalWeight();


//        DailyWeight daily = new DailyWeight(receivedDailyWeight, receivedDate, receivedUsername);
//        mUserdata.addDailyWeight(daily);


//        showDailyWeight.setText(receivedDailyWeight);
//        showDates.setText(daily.getDates());
//        showGoalWeight.setText(goalWeight);



        // Getting goal weight from user
        if (getIntent().getStringExtra("goalWeight") != null) {
            showGoalWeight.setText(receivedGoalWeight + " lbs");
        }

//         Getting daily weight from user
        if (getIntent().getStringExtra("dailyWeight") != null) {
            showDailyWeight.setText(receivedDailyWeight + " lbs");
        }

        // Getting date from user
        if (getIntent().getStringExtra("dates") != null) {
            showDates.setText(getIntent().getStringExtra("dates"));
        }

        //Getting SMS notification status from user
//        if (getIntent().getBooleanExtra("smsNotification", true)) {
//            showSMSNotification.setText("You are getting SMS notification.");
//        }

    }  // End of onCreate

    public void displayList() {
        StringBuffer itemText = new StringBuffer();
        String[] items = mUserdata.getWeightTrends();
        for (int i = 0; i < items.length; i++) {
            itemText.append((i+1)+ ". " + items[i] + "\n");
        }
        showWeightTrends.setText(itemText);
    }
    public void onButtonEditGoalClicked(View view) {
        Intent intent = new Intent(this, EditGoalWeight.class);
        String receivedUsername = getIntent().getStringExtra("username");
        intent.putExtra("receivedUsername", receivedUsername);
        startActivity(intent);
    }

    public void onButtonEditDailyClicked(View view) {
        Intent intent = new Intent(this, EditDailyWeight.class);

        intent.putExtra("loggedIn", loggedIn);
        startActivity(intent);
    }


}