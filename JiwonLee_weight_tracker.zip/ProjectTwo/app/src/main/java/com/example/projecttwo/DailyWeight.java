package com.example.projecttwo;

public class DailyWeight {

    private String dailyWeight;
    private String dates;
    private String username;

    public DailyWeight() {}

    public DailyWeight(String dailyWeight, String dates, String username) {
        this.dailyWeight = dailyWeight;
        this.dates = dates;
        this.username = username;
    }



    public String getDailyWeight() {
        return dailyWeight;
    }

    public void setDailyWeight(String dailyWeight) {
        this.dailyWeight = dailyWeight;
    }

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
