package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class UserData extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "userData.db";
    private static final int VERSION = 1;
    private Context mCxt;
    //private List<Login> userList = new ArrayList<>();
    private List<Login> userList;
    private List<String> mDailyWeightList;


    private static UserData mUserDb;

    public enum DailyWeightSortOrder { ALPHABETIC, UPDATE_DESC, UPDATE_ASC };

    public static UserData getInstance(Context context) {
        if (mUserDb == null) {
            mUserDb = new UserData(context);
        }
        return  mUserDb;
    }

    private UserData(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class LoginTable{
        private static final String TABLE = "login";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_ID = "_id";
    }

    private  static final class GoalWeightTable{
        private static final String TABLE = "Goalweights";
        private static final String COL_GOAL_WEIGHT = "goal";
        private static final String COL_USERNAME = "username";
    }

    private  static final class DailyWeightTable{
        private static final String TABLE = "Dailyweights";
        private static final String COL_DAILY_WEIGHT = "daily";
        private static final String COL_DATES = "dates";
        private static final String COL_USERNAME = "username";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
       // Create login table
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                           LoginTable.COL_ID + " text, " +
                LoginTable.COL_USERNAME + " primary key, " +
                LoginTable.COL_PASSWORD + " text)");
                //+ LoginTable.COL_ID + " text)");

        // Create Goal weight table
        db.execSQL("create table " + GoalWeightTable.TABLE + " (" +
                           GoalWeightTable.COL_GOAL_WEIGHT + ", " +
                           GoalWeightTable.COL_USERNAME + ", " +
                           "foreign key(" + GoalWeightTable.COL_USERNAME + ") references " +
                           LoginTable.TABLE + "(" + LoginTable.COL_USERNAME + ") on delete cascade)");

       // Create Daily weight table
        db.execSQL("create table " + DailyWeightTable.TABLE + " (" +
                           DailyWeightTable.COL_DAILY_WEIGHT + ", " +
                           DailyWeightTable.COL_DATES + ", " +
                           DailyWeightTable.COL_USERNAME + ", " +
                           "foreign key(" + DailyWeightTable.COL_USERNAME + ") references " +
                LoginTable.TABLE + "(" + LoginTable.COL_USERNAME + ") on delete cascade)");



        String[] usernameList = {"Jiwon", "Kyle", "Brynn"};
        for (String id: usernameList) {
            Login login = new Login(id, id);
            ContentValues values = new ContentValues();
            values.put(LoginTable.COL_USERNAME, login.getUsername());
            values.put(LoginTable.COL_PASSWORD, login.getPassword());
            db.insert(LoginTable.TABLE, null, values);
        }

    } // End of onCreate

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop Table if exists " + LoginTable.TABLE);
        db.execSQL("drop Table if exists " + GoalWeightTable.TABLE);
        db.execSQL("drop Table if exists " + DailyWeightTable.TABLE);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                db.execSQL("pragma foreign_keys = on;");
            } else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }

    //CRUD

//============================ Login data

    public boolean addUser(Login login) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_USERNAME, login.getUsername());
        values.put(LoginTable.COL_PASSWORD, login.getPassword());

        long user = db.insert(LoginTable.TABLE, null, values);
        Log.d("addUserData()", "username: " + login.getUsername() +
                "|| password: " + login.getPassword());

        db.close();
        return user != -1;

    }

    public void deleteUser(Login login) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(LoginTable.TABLE, LoginTable.COL_USERNAME + " = ?",
                  new String[]{login.getUsername()});
    }

    public List<Login> getUsernames() {
        List<Login> usersList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + LoginTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                Login login = new Login();
                login.setUsername(cursor.getString(0));
                userList.add(login);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return usersList;
    }


    public List<Login> getLoginData() {
        List<Login> loginList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + LoginTable.TABLE + " where " + LoginTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                Login login = new Login();
                login.setUsername(cursor.getString(0));
                login.setPassword(cursor.getString(1));
                userList.add(login);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return loginList;
    }

//=================================== Goal weight

    public void addGoalWeight(GoalWeight goal) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(GoalWeightTable.COL_GOAL_WEIGHT, goal.getGoalWeight());
        values.put(GoalWeightTable.COL_USERNAME, goal.getUsername());

        db.insert(GoalWeightTable.TABLE, null, values);
        Log.d("addGoalWeight() ", "User: " + goal.getUsername() +
                " added goal weight: " + goal.getGoalWeight());
        db.close();
    }

    public void updateGoalWeight(GoalWeight goal) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GoalWeightTable.COL_GOAL_WEIGHT, goal.getGoalWeight());
        values.put(GoalWeightTable.COL_USERNAME, goal.getUsername());

        db.update(GoalWeightTable.TABLE, values,
                  GoalWeightTable.COL_GOAL_WEIGHT + " =?",
                  new String[] {goal.getGoalWeight()});
    }

    public void deleteGoalWeight(GoalWeight goal) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(GoalWeightTable.TABLE, GoalWeightTable.COL_GOAL_WEIGHT + " =? ",
                  new String[] {goal.getGoalWeight()});
    }

//============================= Daily weight

    public void addDailyWeight(DailyWeight daily) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(DailyWeightTable.COL_DAILY_WEIGHT, daily.getDailyWeight());
        values.put(DailyWeightTable.COL_DATES, daily.getDates());
        values.put(DailyWeightTable.COL_USERNAME, daily.getUsername());

        mDailyWeightList.add(daily.getDailyWeight());
        mDailyWeightList.add(daily.getDates());

        db.insert(DailyWeightTable.TABLE, null, values);
        Log.d("addDailyWeight()", "User: " + daily.getUsername() +
                " added daily weight: " + daily.getDailyWeight());
    }

    public void deleteDailyWeight(DailyWeight daily) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(DailyWeightTable.TABLE, DailyWeightTable.COL_DAILY_WEIGHT + " =? ",
                  new String[] {daily.getDailyWeight()});
    }

    public String[] getWeightTrends() {
        String[] items = new String[mDailyWeightList.size()];
        return mDailyWeightList.toArray(items);
    }

//=====================================

    //Get a password
    public String getPasswordById(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + LoginTable.TABLE +
                " where " + LoginTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {username});

//        if (cursor != null)
//            cursor.moveToFirst();

        String pw;
//        //login.setUsername(cursor.getString(0));
        pw = cursor.getString(1);

        return pw;
    }

    //Get a goal weight
    public GoalWeight getGoalWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(GoalWeightTable.TABLE, new String[]{GoalWeightTable.COL_GOAL_WEIGHT},
                                 GoalWeightTable.COL_USERNAME +"=?", new String[]{username},
                null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        GoalWeight goal = new GoalWeight();
        goal.setGoalWeight(cursor.getString(0));
        return goal;
    }

    public Boolean insertData(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(LoginTable.COL_USERNAME, username);
        contentValues.put(LoginTable.COL_PASSWORD, password);
        long result = db.insert(LoginTable.TABLE, null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }


//
    // When this return true, username already exists.
    // When this return false, username doesn't exists.
//    public Boolean checkUsername(String username) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        Cursor cursor = db.rawQuery("Select * from "+ LoginTable.TABLE + " where " +
//                                            LoginTable.COL_USERNAME + " = ?", new String[]{username});
//        if(cursor.getCount() > 0)
//            return true;
//        else
//            return false;
//    }

//    // Find a password by username
//    public String getPasswordById(String username) {
//        SQLiteDatabase db = getReadableDatabase();
//        String pw = "";
//        String sql = "select * from " + LoginTable.TABLE + " where username = ?";
//        Cursor cursor = db.rawQuery(sql, new String[] { username });
//        if (cursor.moveToFirst()) {
//            do {
//                pw = cursor.getString(2);
//            } while (cursor.moveToNext());
//        }
//        cursor.close();
//        return pw;
//    }

    // Check if username already exists
    public Boolean haveUsername(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        int i = 0;
        Cursor cursor = db.rawQuery("Select * from "+ LoginTable.TABLE + " where " +
                                            LoginTable.COL_USERNAME + " = ?", new String[]{username});
        if (cursor.moveToFirst()) {
            do {
                i++;
            } while (cursor.moveToNext());
        }
        return true != 1>i;
    }


//
//
//    public Boolean isUsernameMatched(String username, String pw) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        Cursor cursor1 = db.rawQuery("Select * from "+ LoginTable.TABLE + " where " +
//                                            LoginTable.COL_USERNAME + " = ?", new String[]{username});
//
//        Cursor cursor2 = db.rawQuery("Select * from "+ LoginTable.TABLE + " where " +
//                                             LoginTable.COL_PASSWORD + " = ?", new String[]{pw});
//
//
//        String matchedPW = cursor1.;
//        String matchedUsername = cursor2.getString(0);

        //Cursor cursor = db.rawQuery("Select * from users where username = ? and password = ?", new String[]{username, pw});
//        if (getIdWithUsername(username) == getIdWIthPW(pw)) {
//            return true;
//        } else {
//            return false;
//        }
//    }

//    public long getIdWithUsername(String username) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        Cursor cursor = db.rawQuery("Select * from "+ LoginTable.TABLE + " where " +
//                                             LoginTable.COL_USERNAME + " = ?", new String[]{username});
//        long idFromUsername = cursor.getLong(0);
//        return idFromUsername;
//    }
//
//    public long getIdWIthPW(String pw) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        Cursor cursor2 = db.rawQuery("Select * from "+ LoginTable.TABLE + " where " +
//                                             LoginTable.COL_PASSWORD + " = ?", new String[]{pw});
//        long idFromPW = cursor2.getLong(0);
//        return idFromPW;
//
//    }



//    public Boolean checkUsernamePassword(String username, String password) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        Cursor cursor = db.rawQuery("Select * from users where username = ? and password = ?", new String[]{username, password});
//        if (cursor.getCount()>0){
//            return true;
//        } else {
//            return false;
//        }
//    }

    //CRUD
    //Add


} //End



