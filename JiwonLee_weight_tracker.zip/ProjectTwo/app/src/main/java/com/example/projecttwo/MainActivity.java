package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText userName, password;
    Button signIn, signUp;
    private UserData mUserdata;
    private Login login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        userName = findViewById(R.id.input_username);
        password = findViewById(R.id.input_password);
        signIn = findViewById(R.id.button_signIn);
        signUp = findViewById(R.id.button_signUp_login);
        mUserdata = UserData.getInstance(getApplicationContext());

    } //End of onCreate

    public void onButtonSignInClicked(View view) {

        String username = userName.getText().toString().trim();
        String pw = password.getText().toString().trim();

        if(!username.isEmpty() && !pw.isEmpty()) {
            Intent intent = new Intent(MainActivity.this, HelloUserActivity.class);
            intent.putExtra("username", username);

            startActivity(intent);
        }else {
            Toast.makeText(MainActivity.this, "Please enter username and password.", Toast.LENGTH_SHORT).show();
        }

//        // When username and password is not empty
//        if (!username.isEmpty() && !pw.isEmpty()) {
//            boolean isAuthenticated = doesUsernameMatch(username, pw);
//            boolean isAuthenticated = doesUsernameExist(username, pw);
//            String vv = mUserdata.getPasswordById(username);
//            List<Login> a = mUserdata.getLoginData();
//            Log.d("userList", "isAuthenticated: " + a.get(1).getUsername());
//            for (int i = 0; i < a.size(); i++) {
//                Log.d("userList", "isAuthenticated: " + a.get(i).getUsername());
//            }
            //Log.d("userList", "isAuthenticated: " + isAuthenticated);
//        } // if end



//
//
//
//            if (isAuthenticated) {
//                Toast.makeText(MainActivity.this, "Username exist", Toast.LENGTH_SHORT).show();
//            }

//            if (isAuthenticated) {
//                Toast.makeText(MainActivity.this, "Signing in successfully", Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent(MainActivity.this, HelloUserActivity.class);
//                intent.putExtra("username", username);
//                startActivity(intent);
//            } else {
//                String msg = "The username " +username+ " and the password doesn't match.";
//                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
//            }
//        }

//        String username = userName.getText().toString().trim();
//        String pw = password.getText().toString().trim();
//
//        boolean isAuthenticated = doesUsernameExist(username, pw);
//        List<Login> userList = mUserdata.getUsernames();
//        //SQLiteDatabase mUserdata = this.mUserdata.getReadableDatabase();
//
//        for (int i = 0; i < userList.size(); i++) {
//            if (userList.get(i).getUsername().equals(username)) {
//                Toast.makeText(MainActivity.this, "Username doesn't exist.", Toast.LENGTH_SHORT).show();
//            }else if (!userList.get(i).getUsername().equals(username) && !userList.get(i).getPassword().equals(pw)) {
//                Toast.makeText(MainActivity.this, "Username and password do not match.", Toast.LENGTH_SHORT).show();
//            }else if (userList.get(i).getUsername().equals(username) && userList.get(i).getPassword().equals(pw)) {
//                Intent intent = new Intent(MainActivity.this, HelloUserActivity.class);
//                startActivity(intent);
//            }
//        }


//        try {
//            String username = userName.getText().toString().trim();
//            String pw = password.getText().toString().trim();
//
//            boolean isAuthenticated = doesUsernameExist(username, pw);
//            if (isAuthenticated) {
//                Intent intent = new Intent(MainActivity.this, HelloUserActivity.class);
//                startActivity(intent);
//            } else {
//                Toast.makeText(MainActivity.this, "Username doesn't exist.", Toast.LENGTH_SHORT).show();
//            }
//        }catch(Exception e) {
//            String error = "";
//            for(StackTraceElement elem: e.getStackTrace()) {
//                error += elem.toString();
//            }
//            Log.e("LoginActivity", error);
//        }

    } // End of onButton click

//        String username = userName.getText().toString().trim();
//        String pw = password.getText().toString().trim();
//
//        if(!username.isEmpty() && !pw.isEmpty()) {
//            Intent intent = new Intent(MainActivity.this, HelloUserActivity.class);
//            startActivity(intent);
//        }else {
//            Toast.makeText(MainActivity.this, "Please enter username and password.", Toast.LENGTH_SHORT).show();
//        }




    public void onButtonSignUpClicked(View view) {
        Intent intent = new Intent(this, SignUpActivity.class);
        startActivity(intent);
    }

    private boolean doesUsernameMatch(String username, String pw) {
        List<Login> userList = new ArrayList<>();
        //SQLiteDatabase db = this.mUserdata.getReadableDatabase();
        userList = mUserdata.getLoginData();


        for (int i = 0; i < userList.size(); i++) {
            if (userList.get(i).getUsername().equals(username) && userList.get(i).getPassword().equals(pw)) {
                return true;
            }
        }
        return false;
    }

    private boolean doesUsernameExist(String username, String pw) {
        List<Login> usernameList = mUserdata.getLoginData();

        for (int i = 0; i < usernameList.size(); i++) {
                if (usernameList.get(i).getUsername().equals(username) &&
                        usernameList.get(i).getPassword().equals(pw)) {
                    return true;
                }
            }
            return false;
        }


}//End